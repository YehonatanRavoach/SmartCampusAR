using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SearchDropdown : MonoBehaviour
{
    [Header("UI References")]
    public TMP_InputField searchInput;
    public GameObject optionPrefab;
    public Transform optionsContainer;
    public ScrollRect scrollRect;

    public CanvasMover canvasMover;


    [Header("Logic")]
    public Action<string> OnOptionSelected;

    public Transform popupLayer;
    public RectTransform fieldReference;
    private Transform originalParent;
    private Vector3 originalPosition;

    private List<string> allOptions = new();
    private readonly List<GameObject> activeOptions = new();
     

    private void Awake()
    {
        scrollRect.gameObject.SetActive(false);
        searchInput.onSelect.AddListener(_ => ExpandDropdown());
        searchInput.onValueChanged.AddListener(ShowFilteredOptions);
    }





    public void SetOptions(List<string> options)
    {
        allOptions = options.OrderBy(x => x).ToList();
        searchInput.text = ""; // clear previous text
        scrollRect.gameObject.SetActive(false);
        ClearOptions();

        if (!string.IsNullOrWhiteSpace(searchInput.text))
        {
            ShowFilteredOptions(searchInput.text);
        }
    }

    public void ExpandDropdown()
    {
        if (allOptions == null || allOptions.Count == 0)
            return;

        ShowFilteredOptions("");

        originalParent = scrollRect.transform.parent;
        originalPosition = scrollRect.transform.position;

        RectTransform scrollRectTransform = scrollRect.GetComponent<RectTransform>();

        Vector3 fieldBottomWorld = fieldReference.TransformPoint(
             new Vector3(0, -fieldReference.rect.height / 2f, 0)
         );

        scrollRect.transform.SetParent(popupLayer, worldPositionStays: false);

        float extraOffset = -40f;
        float scrollHeight = scrollRectTransform.rect.height;

        scrollRectTransform.position = fieldBottomWorld + new Vector3(0, -scrollHeight / 2f + extraOffset, 0);

        if (canvasMover != null)
        {
            canvasMover.MoveCanvasUp();
            

        }


        scrollRect.gameObject.SetActive(true);
        
    }


    private void ShowFilteredOptions(string input)
    {
        ClearOptions();

        string inputClean = input.Trim().ToLower();

        var matches = allOptions
            .Where(o => o.ToLower().Contains(inputClean))
            .OrderBy(o => !o.ToLower().StartsWith(inputClean))
            .ThenBy(o => o)
            .ToList();

        scrollRect.gameObject.SetActive(matches.Count > 0);

        foreach (var match in matches)
        {
            GameObject item = Instantiate(optionPrefab, optionsContainer);
            TMP_Text label = item.GetComponentInChildren<TMP_Text>();
            label.text = match;

            item.GetComponent<Button>().onClick.AddListener(() =>
            {
                searchInput.text = match;

                scrollRect.gameObject.SetActive(false);
                if (canvasMover != null)
                {

                    canvasMover.ResetCanvasPosition();
                    
                     
                }

                scrollRect.transform.SetParent(originalParent, worldPositionStays: true);

                OnOptionSelected?.Invoke(match);
            });

            activeOptions.Add(item);
        }
    }


    private void ClearOptions()
    {
        foreach (GameObject obj in activeOptions)
            Destroy(obj);
        activeOptions.Clear();
    }

    public void SetInteractable(bool value)
    {
        searchInput.interactable = value;
        searchInput.text = value ? "" : ""; // Optional: clear field if disabling
        scrollRect.gameObject.SetActive(false);
    }

}
